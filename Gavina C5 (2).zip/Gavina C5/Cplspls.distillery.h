#ifndef cplspls.distillery.h
#define CPLSPLS_DISTILLERY_H
#include <iostream>
#include <iomanip>
#include <Cmath>
#include <ctime>
#include <string>

using namespace std;




void Header();
string AskName(string name);
double CalculateNetWhiskyVol(double volume, int barrels, double totalVolume);
double CalculateNetWhiskeyVol(double totalVolume, int agingLoss, double volume);
void AskForBarrels(double& rDiameter, double& rHeight, int& rBarrels, int& rAgingLoss);
void DetermineBottles(double volume, int* pBottles, int* pCases, int* pLoneBottles, double* pExtraForCrew);
void WriteResults(string name, double gallons, int agingLoss, int barrels, int Cases, int bottles, int LoneBottles, double extraForCrew);

#endif