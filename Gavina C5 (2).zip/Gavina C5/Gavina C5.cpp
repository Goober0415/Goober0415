// Gavina C5.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Jamie Gavina jgavina@cnm.edu

#include "cplspls.distillery.h"

int main()
{
	string name;
	double totalVolume;
	double volume;
	int barrels = { 0.0 };
	double height = { 0.0 };
	double diameter = { 0.0 };
	double& rDiameter = diameter;
	double& rHeight = height;
	int& rBarrels = barrels;
	double totalVolume;
	int agingLoss;
	int& rAgingloss = agingLoss;
	bool isSteel;
	int bottles;
	int* pBottles = &bottles;
	int cases;
	int* pCases = &cases;
	int LoneBottles;
	int* pLoneBottles = &LoneBottles;
	double ExtraForCrew;
	double* pExtraForCrew = &ExtraForCrew;
	int LoneBottles = 0.39;
	double volume;
	int Cases = (LoneBottles / volume) / 12;
	double ExtraForCrew = Cases % 12;
	int agingLoss;
	int& rAgingLoss = agingLoss;
	string answer;
	Header();
	do
	{
		AskName(name);
		AskForBarrels(rDiameter, rHeight, rBarrels, rAgingLoss);
		cout << "Are your barrels made out of oak or stainless steel? for oak please press 1 and for stainless steel press 0 \n";
		cin >> isSteel;
		cin.ignore();
		if (isSteel == 1)
		{
			CalculateNetWhiskeyVol(totalVolume, agingLoss, volume);
		}
		else if (isSteel == 0)
		{
			CalculateNetWhiskyVol(volume, barrels, totalVolume);
		}
		else
		{
			cout << "Error, you must enter a 0 or a 1 to continue.\n";
		}
		cout << "The diameter of your barrel is: " << diameter << "the height: " << height << "and the number of barrels: " << barrels;
		cout << "The diameter of your barrel is: " << rDiameter << "the height: " << rHeight << "and the number of barrels: " << rBarrels;
		DetermineBottles(volume, pBottles, pCases, pLoneBottles, pExtraForCrew);
		WriteResults(name, totalVolume, agingLoss, barrels, Cases, bottles, LoneBottles, ExtraForCrew);

		cout << "Would you like to calculate another? Yes or no\n";
		if (answer == "Yes")
		{
			continue;
		}
		else if (answer == "No")
		{
			cout << "Thank you for using our program, see you next time! :) \n";
		}

		return 0;
	} while (answer == "No");
}