#include "cplspls.distillery.h"

void Header() 
{

	cout << "Hello, my name is Jamie, ";
	cout << "this program is used to determine aging loss in whiskey products \n";

}

string AskName(string name)
{
	
	cout << "Please enter the name of the whiskey \n";
	getline(cin, name);
	return name;

}


//Ask for barrels - barrel information enter 0 if the barrel is steel 
void AskForBarrels(double& rDiameter, double& rHeight, int& rBarrels, int& rAgingLoss)
{
	//references
	double diameter;
	double height;
	int agingLoss;
	double totalVolume;
	double volume;
	int barrels;
	
	cout << "Please enter the inside diameter of the barrel in inches: \n";
	cin >> rDiameter;
	cout << "Please enter the height if your barrels in inches: \n";
	cin >> rHeight;
	cout << "How many barrels do you have? \n";
	cin >> rBarrels;
	
	
}

double CalculateNetWhiskyVol(double volume, int barrels, double totalVolume)
{
	//stainless steel
	double diameter;
	double height;
	double volume = diameter * height;
	double totalVolume = volume * barrels;
	cout << "Your total volume of all of your barrels before aging is: " << totalVolume << endl;
	return totalVolume;
}

double CalculateNetWhiskeyVol(double totalVolume, int agingLoss, double volume)
{
	//oak
	cout << "Please enter the percentage loss of your whiskey, please enter this in a decimal, example 15% = 0.15";
	cin >> agingLoss;
	totalVolume = volume + (volume * agingLoss);
	return totalVolume;

}

void DetermineBottles(double volume, int* pBottles, int* pCases, int* pLoneBottles, double* pExtraForCrew)
{

	//pointers
	int LoneBottles;
	int Cases;
	double ExtraForCrew;
	cout << "You will yeld\n";
	cout << "Bottles: " << LoneBottles << "cases: " << Cases << "and have this left for your crew: " << ExtraForCrew;
	cout << "Bottles: " << *pLoneBottles << "cases: " << *pCases << "and have this left for your crew: " << *pExtraForCrew;

}

void WriteResults(string name, double totalVolume, int agingLoss, int barrels, int Cases, int bottles, int LoneBottles, double ExtraForCrew)
{

	cout << "Here are all your results!!! :) \n";
	cout << name << endl << "Total Volume : " << totalVolume << "Total loss from aging : " << agingLoss << endl;
	cout << "Number of barrels : " << barrels << "Number of bottles" << bottles << "Number of cases : " << Cases << endl;
	cout << "This is whats left for the crew: " << ExtraForCrew << endl;

}





