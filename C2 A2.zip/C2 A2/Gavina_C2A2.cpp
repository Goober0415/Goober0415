//Jamie Gavina
//jgavina@cnm.edu

#include <iostream>//cout,cin
using namespace std;//standard
int main()
{
    cout << "Jamie Gavina \n";
    cout << "Gavina C2 A2 \n";//this is my header line
    //compute the sum of two given integers
    int A = 4;
    int B = 3;//enter two integers
 
    cout << "Please enter first number" << endl;
    cin >> (int, A);
    cout << "Please enter second number" << endl;
    cin >> (int, B);

    if (A + B = > 10 &&= < 20)//if the sum of the two integers is equal to or more than 10 and less then or equal the 20
    {
        cout << "30" << endl;//if statement is true, yield 30
    }
    else
    {
        cout << "error" << endl;//if statement is false, yield error
    }

    return 0;
}


