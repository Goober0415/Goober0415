#ifndef WIND_CHILL_H
#define WIND_CHILL_H

#include <iostream>
#include <cmath>
#include <string>
//missing a ; syntax error
using namespace std;

void WriteHeader();
//prototype missing ()
double AskForTemperature();
double AskForWindSpeed();
int ValidateTempAndWS(double temp, double speed);
double CalcWindChill(double T, double V);
int DetermineFrostbiteTimes(double T, double V);
void Goodbye();
bool DoAgain();

#endif

