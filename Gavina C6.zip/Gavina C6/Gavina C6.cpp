//ADD YOUR NAME HERE: Jamie Gavina					  

//must include the header file
#include "WindChill.h"

int main()
{
	//missing a ; to close out the line
	cout << "\n\n CIS 1275   C6  Debugging Quiz Assignment:  Windchill & FrostBite"
		<< "\n This program crashes. Can you find and fix the crashing points?\n"
		<< "\n Place a comment above the line where the crash occurs";

		double temp{ 0.0 };
	double wSpeed{ 0.0 }, wChill{ 0.0 };
	int returnCo{ 0 }, fBite{ 0 };
	//missing a " closer
	string answe{ "yes"};


		//do while loop here
		do
		{
			//asked for temp
			//function misspelled
			temp = AskForTemperature();

			//asked for windspeed
			wSpeed = AskForWindSpeed();

			//validated temp and windspeed
			//variable misspelled, Temp should be temp, WSpeed should be wSpeed
			returnCo = ValidateTempAndWS(temp, wSpeed);
			//return codes 0 = all OK, 1 = both invalid, 2 = temp invalid, 3 = wind invalid

			//if all ok
			//return code mispelled
			if (returnCo == 0)
			{
				//calculate windchill
				//calcwindchill Temp should be temp
				wChill = CalcWindChill(temp , wSpeed);

					//calculate frostbite time
				//Temp should be temp WSpeed should be wSpeed
						fBite = DetermineFrostbiteTimes(temp, wSpeed);

						//show the user results
						//Wchill should be wChill 
						cout << "\n\n Temperature is : " << temp;
						cout << "\n\n WindSpeed is : " << wSpeed;
						cout << "\n \n WindChill is : " << wChill;
						//Fbite should be fBite
						if (fBite > 30 || fBite < 0)
							cout << "\n\n Forstbite is not an immediate threat.";
						else
							cout << "\n \n FrostBite is : " << fBite << " minutes. \n\n";

					}//returnCode should be returnCo
					else if (returnCo == 1)
					{
						cout << "\n\n Temperature and WindSpeed is Invalid ";
					}
					else if (returnCo == 2)
					{
						cout << "\n\n Temperature is Invalid ";
					}
					else if (returnCo == 3)
					{
						cout << "\n\n WindSpeed is Invalid ";
					}
					else if (returnCo == 4)
					{
						cout << "\n\n These conditions mean instant death! DO NOT WALK OUTSIDE!";
					}

					cout << "\n\n Do You Want To Go Again? (yes/no) :";
					//answer undefined should be answe
					cin >> answe;
					cin.ignore();
					//missing closer )
				} while (DoAgain());

				Goodbye();

			 return 0;
					}
