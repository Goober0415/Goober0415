//This is my header file
//Jamie Gavina jgavina@cnm.edu

#ifndef EVENORODD.H.CPP
#define EVENORODD_H_CPP
#include<iostream>
#include<string>
#include<vector>
#include<cmath>

using namespace std;

void WriteHeader();
void EvenOrOdd(string name);
void EvenOrOdd(int number);
void EvenOrOdd(char yorn, int number);
#endif
