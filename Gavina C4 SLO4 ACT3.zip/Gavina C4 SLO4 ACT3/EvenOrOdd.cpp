#include "EvenOrOdd.h.cpp"

void WriteHeader()
{
	cout << "The purpose of this program is to determine if a number is even or odd. \n";
	
}

void EvenOrOdd(string name)
{
	cout << "Please enter your name\n";
	cin >> name;
	
}

void EvenOrOdd(int number)
{
	cout << "Please enter a number and I will tell you if it is even or odd. \n";
	cin >> number;
	if (number % 2 == 0)
	{
		cout << "The number you entered " << number << "is even.\n";
	}
	else
	{
		cout << "The number you entered " << number << "is odd.\n";
	}
}

void EvenOrOdd(char yorn,int number)
{
	cout << "Would you like to check another number? y/n? \n";
	cin >> yorn;
		if ('y')
	{
		cout << "Please enter a number and I will tell you if it is even or odd. \n";
	cin >> number;
	if (number % 2 == 0)
	{
		cout << "The number you entered " << number << "is even.\n";
	}
	else
	{
		cout << "The number you entered " << number << "is odd.\n";
	}
	}
	else
	{
		cout << "Thank you for using our program. \n";
		cout << "Goodbye! \n";
	}
		
}


