// C4 SLO 4 Activity 3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//Jamie Gavina jgavina@cnm.edu

#include "EvenOrOdd.h.cpp"

int main()
{
    string name;
    int number;
    char yorn;
   
    WriteHeader();
    EvenOrOdd(name);
    EvenOrOdd(number);
    {
        EvenOrOdd(yorn, number);
    }
   

    return 0;//the functions are void so it returns nothing
}


