#ifndef SUMANDAVERAGE_H
#define SUMANDAVERAGE_H
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

void WriteHeader();
void AskForInts(int nums[], int count);
void CalcSumAndAve(int nums[], int& sum, double& ave);
void DisplayAll(int nums[], int sum, double ave);


#endif
