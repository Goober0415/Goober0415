#include "SumAndAverage.h"

void WriteHeader()
{

	cout << "Hello my name is Jamie \n";
	cout << "Sum and Average\n";
	cout << "This program is used to calculate the sum and average of the elements in an array";

}

void AskForInts(int nums[], int count)
{

	do
	{
		cout << "Please enter a number \n";
		cin >> nums[count];
		count++;
	} while (count < 6);
}

void CalcSumAndAve(int nums[], int& sum, double& ave)
{
	
	for (int i = 0; i < 6; i++)
	{
		int sum = nums[i];
	}
	double ave = static_cast<double>(sum);
	
}

void DisplayAll(int nums[], int sum, double ave)
{
	for (int i = 0; i < 6; i++)
	{
		cout << nums[i] << "\n";
	}
	cout << "Sum: " << sum << endl;
	cout << "Average: " << ave << endl;

}
