// Gavinacomp7Act4.cpp : This file contains the 'main' function. Program execution begins and ends there.
//jgavina@cnm.edu Jamie Gavina


#include "SumAndAverage.h"
int main()
{
	int nums[6];
	int sum = 0;
	int& sum = sum;
	double& ave = ave;
	int count = 0;
	WriteHeader();
	do
	{
	AskForInts(nums[], count);
	CalcSumAndAve(nums[], &sum, &ave);
	DisplayAll(nums[], sum, ave);
	string answer;
	
		cout << "Would you like to try another array? yes/no?\n";
		cin >> answer;
		if (answer == "yes")
		{
			continue;
		}
		while (answer == "no");
		
		cout << "Thank you for using our program :) Goodbye!";

	return 0;
}