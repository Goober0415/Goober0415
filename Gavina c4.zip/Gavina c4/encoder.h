//This is my header file

//libraries included
#define encoder_h
#ifndef  encoder.h

#include <iostream>//input / output
#include <string>// strings
#include <cmath>// math
#include <ctime>//time function
#include <iomanip>// input / output manipulation

//using standard namespace
using namespace std;

//Prototypes:
void WriteHeader();//program header call, no input, no return value
string AskForString();//ask user for message call, returns name
string AskForEncrytedMessage();//ask user for encrypted message call, returns encrypted message
int GetCodeInteger();//get a random code from user or generated call, returns int
string encoder(int codeInteger, string message);//encode the message call, returns int
string decoder(int codeInteger, string encrypted);//decode the message call, returns string


//end if statement
#endif