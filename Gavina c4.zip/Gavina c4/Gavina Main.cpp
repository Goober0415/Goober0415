// Gavina C4.cpp : This file contains the 'main' function. Program execution begins and ends there.
//MAIN

#include "encoder.h"

int main()
{

    //define variable, these variables are local to main
    string message, choice, encrypted, decoded, goAgain;
    int codeInteger, enorde, encoded;


    //call function, introduce the program to the user
    WriteHeader();
    //play loop
    do
    {
        //generate the encryption key, value between 1-36
        codeInteger = GetCodeInteger();
        if (codeInteger == -1)
        {

            continue;

        }
        cout << "Your random number is: \n";
        cout << codeInteger;
        //select one : to encode or two: to decode
        cout << "\nPlease select one: 1. Choose Encode or 2. Choose Decode \n";
        cout << "Please enter 1 or 2 \n";
        cout << "1. Encode \n";
        cout << "2. decode \n";
        cin >> enorde;
        cin.ignore();

        if (enorde == 1) // encode
        {

            //call function ask for string
            message = AskForString();
            //encrypt the message
            encrypted = encoder(codeInteger, message);
            //display the info
            cout << "\n Your message is:   " << message << endl;
            cout << "\n Your encoded message is:  " << encrypted << endl;
            cout << "\n The encryption key is: " << codeInteger << endl;

        }

        else // decode
        {

            //call function ask for encrypted message
            encrypted = AskForEncrytedMessage();
            //decode encrypted message
            decoded = decoder(codeInteger, encrypted);
            //display the info
            cout << "\n Your message is:   " << decoded << endl;
            cout << "\n Your encrypted message is:  " << encrypted << endl;
            cout << "\n The encryption key is: " << codeInteger << endl;

        }

        //ask user if they want to repeat
        cout << "Would you like to try another? yes/no? \n";
        getline(cin, goAgain);

    }

    while (goAgain == "yes");

    cout << "\n Thanks for playing! \n";
    return 0;
}

