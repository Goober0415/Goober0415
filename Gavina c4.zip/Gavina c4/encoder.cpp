//Function

#include "encoder.h"


//function declaration

void WriteHeader()//header function will tell the user about the program
{

	cout << "Hello my name is Jamie :) \n";
	cout << "Encoder / Decoder \n";
	cout << "The program takes a message and encodes it. ";
	cout << "It can also decode an encrypted message with an integer :) \n";

}

int GetCodeInteger()
{

	int codeInteger;
	//enter a code integer between 1 and 35 inclusive
	cout << "Please enter numbers between 1 and 35 \n";
	cout << "\n Or enter 0 to have the program determine a random one \n";
	cin >> codeInteger;
	cin.ignore();

	//if out of range
	if (codeInteger < 0 || codeInteger > 35)
	{

		cout << "You have entered integers out of range! \n";
		cout << "Please try again \n";
		return -1;

	}
	
	//give user random number
	if (codeInteger == 0)
	{

		unsigned int seed = static_cast <unsigned int> (time(nullptr));
		srand(seed);
		return rand() % 35 + 1;

	}
	
	return codeInteger;

}

string AskForString()//this function will be used to ask the user to write a message
{

	string message;
	//enter message in all caps numbers are okay too
	cout << " Please enter a message in all capital characters. Numbers are okay too. :) \n";
	getline(cin, message);
	return message;

}

string AskForEncrytedMessage()//this function will be used to ask the user to provide and encrypted message
{

	string message;
	//enter encrypted message
	cout << " Please enter encrypted message. \n";
	getline(cin, message);
	return message;

}

string encoder(int codeInteger, string message)
{

	for (unsigned int i = 0; i < message.size(); ++i)
	{

		message.at(i) += codeInteger;

	}
	return message;

}

string decoder(int codeInteger, string encrypted)
{

	for (unsigned int i = 0; i < encrypted.size(); ++i)
	{

		encrypted.at(i) -= codeInteger;

	}
	return encrypted;

}
