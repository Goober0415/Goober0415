// C7 SLO 1 Act 1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "functions.h"

int main()
{
	//declare struct variable/ object
	Movies yours, mine;
	//assign values of mine
	mine.title = "Life As a House";
	mine.star = "Christian Handson";
	mine.year = 1998;
	
	WriteHeader();
	AskForFaveMovie(yours);
	cout << "My favorite movie is " << endl;
	PrintMovie(mine);
	PrintMovie(yours);
	Goodbye();
	cout << endl << endl;

	return 0;
}

