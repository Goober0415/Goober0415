#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <iostream>
#include <string>

using namespace std;
struct Movies
{
	
	string title{ "Life As a House" };
	int year{ 1998 };
	string star{ "Christian Hadenson" };
};

void WriteHeader();
void PrintMovie(Movies& movie);//passing the reference
void AskForFaveMovie(Movies& movie);
void Goodbye();

#endif
