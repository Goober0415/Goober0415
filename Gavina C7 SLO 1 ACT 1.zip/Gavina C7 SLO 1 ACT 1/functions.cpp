#include "functions.h"

void WriteHeader()
{

	cout << "This program is designed for getting your favorite movies \n";

}

void PrintMovie(Movies& movie)
{

	cout << movie.title << "staring " << movie.star << "made in " << movie.year << endl;

}

void AskForFaveMovie(Movies& movie)
{

	cout << "What is your favorite movie?\n";
	getline(cin, movie.title);
	cout << "Who is the star of the movie? \n";
	getline(cin, movie.star);
	cout << "What year was it made in? \n";
	cin >> movie.year;
	cin.ignore();

}

void Goodbye()
{

	cout << "Thank you for sharing your favorite movies with us! :) \n";

}
