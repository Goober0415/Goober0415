// 
//
//Libraries in use
#include <iostream>//cin,cout
#include <string>//includes strings
using namespace std;//standard
#define PI 3.141559//PI declared

int main()//start of program
{
    //declare variable
    string metal{ "" };//variable for metal
    string metalChoice{ '' };//variable for type of metal
    double length{ 0,0 }, diameter{ 0,0 }, volume{ 0.0 }, weight{ 0.0 }, density{ 0.0 };//demensions of the metal
    char answer('y');//yes
    //header

    cout << " Finding the weight of cylinder ";//program will start up and display this
    cout << " is stm, loops and math ";//and this

    do //do statement
    {

        //instruction to the user-get mental choice
        cout << " If you will select a metal and enter dimension of your cylinder"//user needs to enter dimensions
            << " the program will calculate the weight " //program calculates the weight
            << " use the two letter abbreviation ";
        cout << " Al, Au, Ag, Pb";//aluminum, gold, silver, lead
        cin >> metalChoice;//enter metal choice
        // Set the metal and density variables
        if (metalChoice == "Au")//if Au is selected
        {
            metal = "Gold";//then Gold is selected
            density = 0.61768;//and its density is 0.61768 lbs per cubic inch
        }
        else if (metalChoice == "Ag")//if Ag is selected
        {
            metal = "Silver";//then Silver is selected
            density = 0.379;//and its density is 0.379 lbs per cubic inch
        }
        else if (metalChoice == "Al")//if Al is selected
        {
            metal = "Aluminum";//then Aluminum is selected
            density = 0.0975;//and the density is 0.0975 lbs per cubic inch
        }
        else if (metalChoice == "Pb")//if Pb is selected
        {
            metal = "Lead";//then Lead is selected
            density = 0.41;//and the density is 0.41 lbs per cubic inch
        }
        else
        {
            cout << "We cannot calculate this metal at this time" << endl;
        }
       
        
        //get cylinder dimension
        cout << " Enter the length or height of the cylinder in inches ";//we ask the user for the length
        cin >> length;//the user provides the length
        cout << "Enter diameter";//we ask the user for the diameter
        cin >> diameter;//the user provides the diameter

        //calculate the volume and weight of the cylinder (length * width * height)

        volume = PI * diameter * diameter * length / 4.0;//this is the calculation for the weight of the cylinder
        weight =;
            //set the weight
            //set precision for output

        //display the information to the user
        //ask user if they want to calculate another cylinder
        cout << "would you like to calculate another cylinder?\n";
        cin >> char answer;
       
    }
}


