//Jamie Gavina jgavina@cnm.edu
#ifndef RETURNTWONUMBERS.H
#define RETURNTWONUMBERS_H
#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>
#include<ctime>


using namespace std;
void Writeheader();
int AskForTwoNumbers(int num1, int num2);
int FindBigOne(int num1, int num2, int bigone);
string GoAgain();


#endif